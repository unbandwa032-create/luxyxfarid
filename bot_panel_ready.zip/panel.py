import requests
from config import PANEL_URL, API_KEY

def create_user(username, password, email):
    url = f"{PANEL_URL}/api/application/users"
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json",
        "Accept": "Application/vnd.pterodactyl.v1+json"
    }

    data = {
        "email": email,
        "username": username,
        "first_name": username,
        "last_name": "User",
        "password": password
    }

    r = requests.post(url, json=data, headers=headers)
    return r.json()
