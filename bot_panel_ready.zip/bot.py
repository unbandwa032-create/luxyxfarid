import json, time, random, string
from telegram import *
from telegram.ext import *
from config import *
from panel import create_user

def load_db():
    with open("database.json") as f:
        return json.load(f)

def save_db(data):
    with open("database.json", "w") as f:
        json.dump(data, f)

def gen_pass():
    return ''.join(random.choices(string.ascii_letters + string.digits, k=8))

def gen_garansi():
    return "GAR-" + ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    db = load_db()
    user_id = str(update.effective_user.id)

    if user_id not in db["users"]:
        db["users"][user_id] = {"saldo": 0, "role": "user"}
        save_db(db)

    keyboard = [
        [InlineKeyboardButton("Beli Panel", callback_data="buy")],
        [InlineKeyboardButton("Saldo", callback_data="saldo")]
    ]

    await update.message.reply_text(
        "Selamat datang di bot panel!",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    db = load_db()
    user_id = str(query.from_user.id)

    if query.data == "saldo":
        saldo = db["users"][user_id]["saldo"]
        await query.edit_message_text(f"Saldo: {saldo}")

    elif query.data == "buy":
        await query.edit_message_text(
            "Pilih paket:",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("1GB", callback_data="1gb")],
                [InlineKeyboardButton("2GB", callback_data="2gb")]
            ])
        )

    elif query.data in ["1gb", "2gb"]:
        harga = 2000 if query.data == "1gb" else 3000

        if db["users"][user_id]["saldo"] < harga:
            await query.edit_message_text("Saldo tidak cukup")
            return

        db["users"][user_id]["saldo"] -= harga

        username = f"user{user_id}"
        password = gen_pass()
        email = f"{username}@gmail.com"

        user = create_user(username, password, email)

        if "attributes" in user:
            kode = gen_garansi()
            expired = time.time() + (30*24*60*60)

            db["garansi"][kode] = {
                "user": user_id,
                "expired": expired
            }

            save_db(db)

            await context.bot.send_message(
                chat_id=int(user_id),
                text=f"PANEL AKTIF\n\nLogin: {PANEL_URL}\nUser: {username}\nPass: {password}\n\nGaransi 30 Hari\nKode: {kode}"
            )

app = ApplicationBuilder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CallbackQueryHandler(button))

if __name__ == "__main__":
    print("Bot jalan...")
    app.run_polling(drop_pending_updates=True)
